PSO
Fitness Parameters:
1.Schedule Length(0.4)
2.Cost(0.3)
3.Vm Utilization(0.3)


For Calculation of Cost
Sigma=2
Tau=3
VCBase=2
CPUCYCLE=[2,3.5,4.5,5.5,6.5]

PSO:
w = 0.7968-->Inertia Factor
c1 = 1.4962-->Acceleration Factor
c2 = 1.4962-->Acceleration Factor
