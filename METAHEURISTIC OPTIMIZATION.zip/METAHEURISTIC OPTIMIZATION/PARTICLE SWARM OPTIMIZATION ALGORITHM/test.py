def ravi(a):
    a[0]=[]

a=[[1,2,3],[5,6,7]]
ravi(a)
print(a)