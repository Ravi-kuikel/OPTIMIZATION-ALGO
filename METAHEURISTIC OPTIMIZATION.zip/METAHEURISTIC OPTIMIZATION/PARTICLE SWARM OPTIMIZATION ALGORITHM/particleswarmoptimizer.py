from math import modf
import random  as rd
import Dag as yo
import os
import glob
import pathlib
import heft_Rank as heft
import time
from progress.bar import IncrementalBar
import matplotlib.pyplot as plt



class particleswarm:
    def __init__(self, p, n,m):  # Step 1
        self.w = 0.7968  # inertia factor
        self.c1 = 1.4962  # Acceleration factor
        self.c2 = 1.4962  # Accceleration factor
        self.p = p #Population Size
        self.n = n #No of Task
        self.m=  m #No of VM
        self.position = []
        self.velocity = []
        # Inializing velocity and position
        for i in range(self.p):
            ar = []
            for j in range(self.n):
                ar.append(round(rd.random(), 3))
            self.position.append(ar)
        for i in range(self.p):
            ma = []
            for j in range(self.n):
                ma.append((self.position[i][j] * 0.1))
            self.velocity.append(ma)
        # currentposition at 0 iteration cp=position+velocity
        for i in range(p):
            for j in range(n):
                self.position[i][j] = (self.position[i][j] + self.velocity[i][j])

        self.xbest = []
        for i in range(self.p):
            arr = []
            for j in range(self.n):
                arr.append(self.position[i][j])
            self.xbest.append(arr)

    def algo(self):
        flag=1####For plotting graph
        FTb = self.fitness()  # Step 2
        gbest = []
        value = min(FTb)
        index = FTb.index(value)
        for i in self.position[index]:
            gbest.append(i)
        '''print("Initial Position")
        print()
        self.printposition(self.position)
        print()
        print("After Conversion to vm")
        print()
        self.vmcorresponding(self.position)
        print()
        print("Fitness Value")
        for i in FTb:
            print(i)
        print()
        print("Global best",gbest)
        print()
        print("After Conversion to vm")
        self.vmforparticle(gbest)
        print()
        th=[10]
        print()
        print("Iterations Begin")
        print()'''

        iter = 10 #########################################################################################no of iterations#####################################################################################################
        n = iter
        a = os.getcwd()
        a = a[:len(a) - 6]
        a = a + "/RESULTS/" + str(self.p) + 'X' + str(iter)
        try:
            os.mkdir(a)
        except OSError as error:
            pass

        a = a + '/' + name
        f = open(a, 'a+')
        x = " "
        f.write("Sequence\n")
        f.write(x.join(map(str, obj.seq)))
        f.write("\n")
        f.write("\n")
        prev=10000
        counter=0
        bar=IncrementalBar("Processing",max=iter)
        x=[]
        y=[]
        while iter > 0:

            self.updatevelocity(gbest)
            self.updateposition()
            '''print("Iteration ", (n - iter + 1))
            print()
            print("After Updating position")
            print()
            self.printposition(self.position)
            print()
            print("After Converting it to Vm")
            print()
            self.vmcorresponding(self.position)'''
            FTc = self.fitness()
            '''print("Fitness Value Corresponding to it is")
            self.printfitness(FTc)'''
            value = self.updateglobalbest(FTb, FTc, gbest, value)
            x.append(n-iter+1)
            y.append(value)

            '''print("Current Best")
            print()
            self.printposition(self.xbest)
            print()
            print("Vm corresponding to it is")
            self.vmcorresponding(self.xbest)
            print()
            print("Fitness Value Corresponding to it is")
            self.printfitness(FTb)
            print()
            print("GlobalBest Position", gbest)
            print()
            print("Vm Corresponding to it is")'''
            ba = self.vmforparticle(gbest)

            #print()
            time = obj.makespan(ba)
            cost = obj.cost(ba)
            vu=obj.vmutilization(ba,cost)
            en=obj.energy(ba,time)
            su=obj.speedup(time)
            lo=obj.loadbalancing(ba)
            '''print("Makespan Corresponding to GlobalBest= ", time)
            print("Cost=", cost)
            print("Vm Utilization=",vu)
            print("Fitness=", value)'''
            if value<prev:
                a=" "
                counter=counter+1
                s="Fitness="+str(value)
                f.write(s)
                f.write("\n")
                a = " "
                s = "Makespan= " + str(time)
                f.write(s)
                f.write("\n")
                s = "Cost=" + str(cost)
                f.write(s)
                f.write("\n")
                s="Vm Utilization="+str(vu)
                f.write(s)
                f.write("\n")
                s="SpeedUp="+str(su)
                f.write(s)
                f.write("\n")
                s = "Energy=" + str(en)
                f.write(s)
                f.write("\n")
                s = "LoadBalancing=" + str(lo)
                f.write(s)
                f.write("\n")
                f.write(a.join(map(str, ba)))
                f.write("\n")
                f.write("\n")
                prev=value
            iter -= 1
            bar.next()
        if flag==1:
            plt.plot(x, y)
            plt.xlabel("ITERATIONS")
            plt.ylabel("FITNESS")
            plt.title(name)
            plt.show()
        bar.finish()
        f.close()

    def fitness(self):
        ft = []
        sln = []
        pun = []
        vun=[]
        for i in range(self.p):
            ar = []
            for j in range(self.n):
                a, b = modf(self.position[i][j])
                if a < 0:
                    a = a * -1
                a = round(a, 3)
                a = a * 1000
                s = 0
                while a > 0:
                    r = a % 10
                    s = s + r
                    a = a // 10
                ar.append(int(s % m + 1))
            sl = obj.makespan(ar)
            price = obj.cost(ar)
            vu=obj.vmutilization(ar,sl)
            sln.append(sl)
            pun.append(price)
            vun.append(vu)

        self.slmax = max(sln)
        self.pumax = max(pun)
        self.vmax = max(vun)

        for i in range(self.p):
            ft.append(obj.w1 * (sln[i] / self.slmax) + obj.w2 * (pun[i] / self.pumax) + obj.w3 *(1-(vun[i]/self.vmax)))
        return ft

    def updatevelocity(self, gbest):
        for i in range(self.p):
            for j in range(self.n):
                self.velocity[i][j] = (self.w * self.velocity[i][j]) + (
                        (self.c1 * rd.random()) * (self.xbest[i][j] - self.position[i][j])) + (
                                              (self.c2 * rd.random()) * (gbest[j] - self.position[i][j]))

    def updateposition(self):
        for i in range(self.p):
            for j in range(self.n):
                self.position[i][j] = (self.position[i][j] + self.velocity[i][j])
    def updateglobalbest(self,FTb,FTc,gbest,value):
        for i in range(self.p):  # Updating Global best and xbest
            if FTb[i] > FTc[i]:
                self.xbest[i] = []
                for k in self.position[i]:
                    self.xbest[i].append(k)
                # Update xbest
                FTb[i] = FTc[i]  # Update Best Fitness
        value=min(FTb)
        index=FTb.index(value)
        for i in range(len(self.xbest[index])):
            gbest[i]=self.xbest[index][i]
        return value

    def vmcorresponding(self,arr):
        for i in range(len(arr)):
            for j in range(len(arr[0])):
                a, b = modf(arr[i][j])
                if a < 0:
                    a = a * -1
                a = round(a, 3)
                a = a * 1000
                s = 0
                while a > 0:
                    r = a % 10
                    s = s + r
                    a = a // 10
                print(int(s % m + 1), end=" ")
            print()

    def vmforparticle(self,arr):
        x=[]
        for j in range(len(arr)):
            a, b = modf(arr[j])
            if a < 0:
                a = a * -1
            a = round(a, 3)
            a = a * 1000
            s = 0
            while a > 0:
                r = a % 10
                s = s + r
                a = a // 10
            '''print(int(s % m + 1), end=" ")'''
            x.append(int(s%m+1))
        '''print()'''
        return x



    def printposition(self,arr):
        for i in range(len(arr)):
            for j in range(len(arr[0])):
                print(arr[i][j],end=" ")
            print()
    def printfitness(self,fitness):
            for i in fitness:
                print(i)
os.chdir(r"input")
myFiles = glob.glob('*.txt')
obj=None
pop = int(input("Enter population Size"))
begin=time.time()
for z in myFiles:
    
    name =z
    t = open(name, 'r')  # Opening Files
    t1 = t.readlines()
    n, m = t1[0].split()
    n = int(n)  # no of task
    m = int(m)  # no of vm
    arr = []
    for i in range(1, n + 1):
        arr.append(t1[i].strip().split())
    eTime = []  # Execution matrix
    for i in range(n):
        x = []
        for j in range(m):
            x.append(float(arr[i][j]))
        eTime.append(x)
    arr = []
    for i in range(n + m + 1, 2 * n + m + 1):
        arr.append(t1[i].strip().split())
    dag = []  # DAG in adjacency matrix format
    for i in range(n):
        x = []
        for j in range(n):
            x.append(float(arr[i][j]))
        dag.append(x)
    
    obj = yo.DAG(dag, n, m, eTime,0.7,0.2)
    obj.seq=(heft.HEFT(name))
    sum = 0
    for i in obj.seq:
        mx = 0
        for j in range(len(eTime[0])):
            if mx < obj.eTime[i - 1][j]:
                mx = obj.eTime[i - 1][j]
        sum = sum + mx

    obj.smake = sum
    
    obj2 = particleswarm(pop, n,m)
    obj2.algo()
    t.close()
end=time.time()
print("Time required:",end-begin)
