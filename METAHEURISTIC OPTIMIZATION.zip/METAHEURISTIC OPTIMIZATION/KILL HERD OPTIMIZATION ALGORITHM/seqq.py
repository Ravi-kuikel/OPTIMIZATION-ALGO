import os
from itertools import permutations as pm
class bfs:
	def seq(self,name):
		a=os.getcwd()
		print(a)
		path=a+'/'+name
		f=open(path,'r')
		t1=f.readlines()
		n,m=t1[0].split()

		n=int(n)
		m=int(m)
		arr = []

		for i in range(n + m + 1, 2 * n + m + 1):
			arr.append(t1[i].strip().split())

		dag = []  # DAG in adjacency matrix format
		for i in range(n):
			x = []
			for j in range(n):
				x.append(float(arr[i][j]))
			dag.append(x)
		prr=[]#This list holds the knowledge of parents
		for i in range(n):
			prr.append([])
		for i in range(n):
			for j in range(n):
				if i != j:
					if dag[j][i]!=0 and dag[j][i]!=-1:
						prr[i].append((j + 1))
		chh=[]
		for i in range(n):
			chh.append([])
		for i in range(n):
			for j in range(n):
				if i!=j:
					if dag[i][j]!=0 and dag[i][j]!=-1:
						chh[i].append(j+1)


		queue=[]
		for i in range(n):
			if len(prr[i])==0:
				queue.append(i+1)

		s=[]
		visited=[]
		for i in range(n):
			visited.append(0)

		while len(queue)!=0:
			s.append(queue[0])
			visited[queue[0]-1]=1
			child=chh[queue[0]-1]
			queue.pop(0)
			if len(child)!=0:
				for i in child:
					if visited[i-1]==0:
						queue.append(i)
						visited[i-1]=1
		return s
if __name__=='main':
	obj=bfs()
	print(obj.seq("8t3.txt"))


