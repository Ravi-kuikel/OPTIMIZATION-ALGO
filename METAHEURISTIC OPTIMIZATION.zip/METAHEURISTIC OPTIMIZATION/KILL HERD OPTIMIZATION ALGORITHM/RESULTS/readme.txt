KILL HERD OPTIMIZATION ALGORITHM

INERTIA WEIGHT(W)=0.3
DMAX=0.05-->FOR PHYSICAL DIFFUSION CALCULATION
VF(FORAGING SPEED)=0.02
NMAX(MAXIMUM INDUCED MOTION)=0.01
TAU=0.0000000001
CT=0.03-->FOR CHANGE IN T CALCULATIONS

FITNESS FUNCTION:
1.SCHEDULE LENGTH
2.PRICE
3.LOAD BALANCING
4.ENERGY CONSUMTION

DAG CONSTANTS
self.sigma = 2
self.tau = 3
w1=0.4#####Schedule Length**************************************************
w2=0.2#####Price****************************************************************
w3=0.3#####loadbalancing*********************************************************************************************
w4=0.1######Energy*********************************************************************************************************
vcbase = 2
cpucycle=[2,3.5,4.5,5.5,6.5]

