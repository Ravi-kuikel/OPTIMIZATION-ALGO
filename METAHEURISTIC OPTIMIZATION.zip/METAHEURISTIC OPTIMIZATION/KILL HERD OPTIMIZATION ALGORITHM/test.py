import random
position=[[1,2,3,4,5],[6,7,8,9,10]]
m=4
a1=[]
b1=[]
for i in range(m+1,len(position[0])):
    a1.append(position[1][i])
    b1.append(position[0][i])
for i in range(0,m):
    position[0][i]=a1[i]
    position[1][i]=b1[i]
print(position)

