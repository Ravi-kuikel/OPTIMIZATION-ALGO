import random
import os
import math
import Dag as yo
import seqq
import glob
import time
from math import modf
import pathlib
import tabulate
import matplotlib.pyplot as plt

class kh:
    def __init__(self, p, n, m):
        self.ct = 0.03 # For Change in t calculations
        self.w = 0.3  # inertia weight
        self.dmax = 0.05 # Needed in physical diffusion calculations
        self.vf = 0.02  # Foraging speed
        self.nmax = 0.01  # maximum induced motion
        self.p = p  # Populations size
        self.n = n  # No of tasks
        self.m = m  # Total no of vm
        self.tau = 0.0000000001

        self.position = []  # Initializing populations of krill randomly
        for i in range(p):
            x = []
            for j in range(n):
                x.append(round(random.random(), 3))
            self.position.append(x)

        self.xbest = []  # Current best is equal to initial position intially
        for i in range(p):
            self.xbest.append(self.position[i])

        self.ni = []
        for i in range(p):
            x = []
            for j in range(n):
                x.append(0)
            self.ni.append(x)
        self.fi = []
        for i in range(p):
            x = []
            for j in range(n):
                x.append(0)
            self.fi.append(x)
        self.di = []
        for i in range(p):
            x = []
            for j in range(n):
                x.append(0)
            self.di.append(x)
        self.delt = self.ct * n * (m - 1)  # used in motion process of kh algorithm

    def krillherdoptimization(self):
        flag=0
        iter = int(input("Enter Total no of iterations\n"))
        ft = self.fitness()
        ftb = self.fitness()
        self.Imax = iter
        prev = 0
        count = 0
        a = os.getcwd()
        a = a[:len(a) - 6]
        a = a + "/RESULTS/" + str(self.p) + 'X' + str(iter)
        try:
            os.mkdir(a)
        except OSError as error:
            pass

        a = a + '/' + name
        f = open(a, 'a+')
        x = " "
        f.write(x.join(map(str, obj.seq)))
        f.write("\n")
        f.write("\n")
        '''print("INITIAL POPULATION\n")
        self.print(self.position)
        print("Fitness=",ft)
        print()
        print()'''
        x=[]
        y=[]
        while count < iter:

            self.I = count + 1
            self.inducedmotion(ft,ftb)
            '''print("Induced Motion")
            self.print(self.ni)'''
            self.foragingmotion(ft, ftb)
            '''print("Forgaging motion")
            self.print(self.fi)'''
            self.physicaldiffusion()
            '''print("Diffusion")
            self.print(self.di)'''
            self.crossover(ft,ftb)
            '''print("After Cross Over")
            self.print(self.position)'''
            self.motionprocess()
            '''print("New Position")
            self.print(self.position)'''
            ft=self.fitness()
            '''print("Fitness=",ft)
            print()
            print()'''
            self.updateglobalbest(ftb, ft)
            '''print("Xbest")
            self.print(self.xbest)
            print("Current Best=", ftb)
            print("\n")'''

            i = ftb.index(min(ftb))
            gbest = self.xbest[i]
            '''print("Global best=",gbest)
            print("\n")'''

            value = ftb[i]
            #print("Value=",value )
            if value != prev:
                self.write(gbest, f,value)
                prev=value
            x.append(count + 1)
            y.append(value)

            count=count+1
        if flag==1:
            plt.plot(x,y)
            plt.xlabel("ITERATIONS")
            plt.ylabel("FITNESS")
            plt.title(name)
            plt.show()
        f.close()

    def inducedmotion(self, ft,ftb):
        alpha = self.localeffect(ft,ftb)
        for i in range(self.p):
            for j in range(self.n):
                self.ni[i][j] = self.nmax * alpha[i][j] + self.w * self.ni[i][j]

    def localeffect(self, ft,ftb):#O(p^2xn)
        alocal = []
        for i in range(self.p):
            x = []
            for j in range(self.n):
                x.append(0)
            alocal.append(x)
        sd = []  # Sensing distance of each particle
        for i in range(self.p):
            s = 0
            for j in range(self.p):
                x = 0
                if i != j:
                    for k in range(self.n):
                        x = x + math.pow(self.position[i][k] - self.position[j][k], 2)
                    s = s + math.sqrt(x)
            sd.append((1 / (5 * self.p)) * s)
        #print(sd,'\n')
        neighbour = []
        for i in range(self.p):
            neighbour.append([])

        for i in range(self.p):
            for j in range(self.p):
                x = 0
                if i != j:
                    for k in range(self.n):
                        x = x + math.pow(self.position[i][k] - self.position[j][k], 2)
                    if math.sqrt(x) <=sd[i]:
                        neighbour[i].append(j)

        ##print('neighbour=',neighbour, '\n')
        for i in range(self.p):
            if len(neighbour[i]) > 0:
                for j in range(self.n):
                    s = 0
                    for k in neighbour[i]:
                        if ft[i]>ft[k]:
                            kij = (ft[i] - ft[k]) / (max(ft) - min(ftb))
                            xij = (self.position[i][j] - self.position[k][j]) / (
                                    math.sqrt(math.pow(self.position[i][j] - self.position[k][j], 2)) + self.tau)
                        else:
                            kij=0
                            xij=0
                        s = s + kij * xij
                    alocal[i][j] = s

        atarget = []
        cbest = 2 * (random.random() + self.I / self.Imax)
        for i in range(self.p):
            x = []
            for j in range(self.n):

                kibest = (ft[i] - min(ftb)) / (max(ft) - min(ftb))
                xibest = (self.position[i][j] - self.xbest[ftb.index(min(ftb))][j]) / (math.sqrt(
                    math.pow(self.position[i][j] - self.xbest[ftb.index(min(ftb))][j], 2)) + self.tau)
                x.append(cbest * kibest * xibest)
            atarget.append(x)

        alpha = []

        for i in range(self.p):
            x = []
            for j in range(self.n):
                x.append(alocal[i][j] + atarget[i][j])
            alpha.append(x)

        return alpha

    def foragingmotion(self, ft, ftb):
        bi = []
        bifood = []
        xfood = []
        for i in range(self.n):
            s = 0
            s1 = 0
            for j in range(self.p):
                s = s + (self.position[j][i] / ft[j])
                s1 = s1 + (1 / ft[j])
            xfood.append(s / s1)
        xifood = 0
        cfood = 2 * (1 - (self.I / self.Imax))
        for i in range(self.p):
            x = []
            for j in range(self.n):

                kifood = (ft[i] - self.fit(xfood)) / (max(ft) - min(ftb))
                xifood = (self.position[i][j] - xfood[j]) / (math.sqrt(math.pow(self.position[i][j] - xfood[j], 2)) + self.tau)

                x.append(cfood * kifood * xifood)
            bifood.append(x)

        bibest = []
        for i in range(self.p):
            x = []
            for j in range(self.n):
                if ft[i] > ftb[i]:
                    kibest = (ft[i] - ftb[i]) / (max(ft) - min(ftb))
                else:
                    kibest=0
                xibest = (self.position[i][j] - self.xbest[i][j]) / (
                        math.sqrt(math.pow(self.position[i][j] - self.xbest[i][j], 2)) + self.tau)
                x.append(kibest * xibest)
            bibest.append(x)
        for i in range(self.p):
            x = []
            for j in range(self.n):
                x.append(bifood[i][j] + bibest[i][j])
            bi.append(x)

        for i in range(self.p):
            for j in range(self.n):
                self.fi[i][j] = self.vf * bi[i][j] + self.w * self.fi[i][j]

    def physicaldiffusion(self):
        for i in range(self.p):
            for j in range(self.n):
                de = random.choice([-1, 1]) * random.random()
                self.di[i][j] = (self.dmax * de * (1 - (self.I / self.Imax)))

    def motionprocess(self):
        for i in range(self.p):
            for j in range(self.n):
                self.position[i][j] = self.position[i][j] + self.delt * (self.fi[i][j] + self.ni[i][j] + self.di[i][j])

    def fitness(self):
        ft = []
        sln = []
        sun = []
        pun = []
        en = []
        ld=[]
        vmu=[]
        for i in range(self.p):
            ar = []
            for j in range(self.n):
                a, b = modf(self.position[i][j])
                if a < 0:
                    a = a * -1
                a = round(a, 3)
                a = a * 1000
                s = 0
                while a > 0:
                    r = a % 10
                    s = s + r
                    a = a // 10
                ar.append(int(s % m + 1))
            sl = obj.makespan(ar)
            #su = obj.speedup(sl)
            price = obj.cost(ar)
            tenergy = obj.energy(ar, sl)
            load=obj.loadbalancing(ar)
            #vmu=obj.vmutilization(ar,sl)
            sln.append(sl)
            #sun.append(su)
            pun.append(price)
            en.append(tenergy)
            ld.append(load)
            #vmu.append(vmu)
        self.slmax = max(sln)
        self.pumax = max(pun)
        self.enmax = max(en)
        #self.sumax=max(sun)
        self.ldmax=max(ld)
        #self.vmmax=max(vmu)

        for i in range(self.p):
            ft.append(obj.w1 * (sln[i] / self.slmax) + obj.w2 * (pun[i] / self.pumax) + obj.w3 * (ld[i] / self.ldmax)+obj.w4*(en[i]/self.enmax))
        return ft

    def updateglobalbest(self, FTb, FTc):# O(p)
        for i in range(self.p):  # Updating Global best and xbest
            if FTb[i] > FTc[i]:
                self.xbest[i] = []
                for j in self.position[i]:
                    self.xbest[i].append(j)
                # Update xbest
                FTb[i] = FTc[i]  # Update Best Fitness

    def fit(self, mat):
        ar = []
        for j in range(self.n):
            a, b = modf(mat[j])
            if a < 0:
                a = a * -1
            a = round(a, 3)
            a = a * 1000
            s = 0
            while a > 0:
                r = a % 10
                s = s + r
                a = a // 10
            ar.append(int(s % m + 1))
        sl = obj.makespan(ar)
        #su = obj.speedup(sl)
        price = obj.cost(ar)
        tenergy = obj.energy(ar, sl)
        load=obj.loadbalancing(ar)
        #vmu=obj.vmutilization(ar,sl)

        ft = (obj.w1 * (sl / self.slmax) + obj.w2 * (price / self.pumax) + obj.w4 * (tenergy / self.enmax) + obj.w3 * (load/self.ldmax))
        return ft

    def write(self, gbest, f,value):
        ba = self.vmforparticle(gbest)
        sl = obj.makespan(ba)
        price = obj.cost(ba)
        su = obj.speedup(sl)
        tenergy = obj.energy(ba, sl)
        vutil = obj.vmutilization(ba, sl)
        load = obj.loadbalancing(ba)
        '''print("Values Corresponding to alpha\n")
        print(tabulate([[sl, price, su, tenergy, value]],
                       headers=['Schedule Length', 'Cost', 'Speedup', 'Energy', 'Fitness']), "\n")
        print("Iteration ", count + 1, "\n")'''

        if 2 > 1:
            s = "Fitness=" + str(value)
            f.write(s)
            f.write("\n")
            a = " "
            s = "Schedulelength= " + str(sl)
            f.write(s)
            f.write("\n")
            s = "Cost=" + str(price)
            f.write(s)
            f.write("\n")
            s = "Speedup=" + str(su)
            f.write(s)
            f.write("\n")
            s = "EnergyConsumption=" + str(tenergy)
            f.write(s)
            f.write("\n")
            s = "Vmutilization=" + str(vutil)
            f.write(s)
            f.write("\n")
            s = "LoadBalancing=" + str(load)
            f.write(s)
            f.write("\n")
            a = ""
            f.write("Vm Allocation \n")
            f.write(a.join(map(str, ba)))
            f.write("\n")
            f.write("\n")

    def vmforparticle(self, arr):
        x = []
        for j in range(len(arr)):
            a, b = modf(arr[j])
            if a < 0:
                a = a * -1
            a = round(a, 3)
            a = a * 1000
            s = 0
            while a > 0:
                r = a % 10
                s = s + r
                a = a // 10
            ##print(int(s % m + 1), end=" ")
            x.append(int(s % m + 1))
        return x

    def crossover(self,ft,ftb):
        for i in range(self.p):
            cr=0.2*(ft[i]-min(ftb))/(max(ft)-min(ftb))
            m=random.randint(0,self.m-1)
            r=random.randint(0,self.p-1)
            if random.random()<cr:
                l1=[]
                l2=[]
                for j in range(m):
                    l1.append(self.position[i][j])
                    l2.append(self.position[r][j])
                r1=[]
                r2=[]
                for j in range(m+1,self.n):
                    r1.append(self.position[i][j])
                    r2.append(self.position[r][j])
                m1=self.position[i][m]
                m2=self.position[r][m]
                fp1=self.fit(self.position[i])
                fp2=self.fit(self.position[r])
                ch1=[]
                ch2=[]
                for j in range(m):
                    ch1.append(l1[j])
                    ch2.append(l2[j])
                ch1.append(m1)
                ch2.append(m2)
                for j in range(len(r1)):
                    ch1.append(r2[j])
                    ch2.append(r1[j])
                fc1=self.fit(ch1)
                fc2=self.fit(ch2)
                if fc1<fp1:#If 1st child is more fit than 1st parent
                    self.position[i]=[]
                    for j in ch1:
                        self.position.append(j)
                if fc2<fp2:#If 2nd child is more is more fir than 2nd parent
                    self.position[r]=[]
                    for j in ch2:
                        self.position[r].append(j)

                
                for j in range(len(l1)):
                    self.position[i].append(l2[j])
                    self.position[r].append(l1[j])
                self.position[i].append(m1)
                self.position[r].append(m2)
                for j in range(len(r1)):
                    self.position[i].append(r2[j])
                    self.position[r].append(r1[j])

    def print(self,arr):
        for i in range(self.p):
            for j in range(self.n):
                print(arr[i][j],end=" ")
            print()
        print()
        print()







os.chdir(r"input")
myFiles = glob.glob('*.txt')
obj = None
pop = int(input("Enter population Size\n"))
begin = time.time()
for z in myFiles:

    name = z
    t = open(name, 'r')  # Opening Files
    t1 = t.readlines()
    n, m = t1[0].split()
    n = int(n)  # no of task
    m = int(m)  # no of vm
    arr = []

    for i in range(1, n + 1):
        arr.append(t1[i].strip().split())
    eTime = []  # Execution matrix
    for i in range(n):
        x = []
        for j in range(m):
            x.append(float(arr[i][j]))
        eTime.append(x)
    arr = []
    for i in range(n + m + 1, 2 * n + m + 1):
        arr.append(t1[i].strip().split())
    dag = []  # DAG in adjacency matrix format
    for i in range(n):
        x = []
        for j in range(n):
            x.append(float(arr[i][j]))
        dag.append(x)

    obj = yo.DAG(dag, n, m, eTime, 0.7, 0.2)
    bj = seqq.bfs()
    obj.seq = bj.seq(name)
    sum = 0
    for i in obj.seq:
        mx = 0
        for j in range(len(eTime[0])):
            if mx < obj.eTime[i - 1][j]:
                mx = obj.eTime[i - 1][j]
        sum = sum + mx

    obj.smake = sum

    obj2 = kh(pop, n, m)
    obj2.krillherdoptimization()
    
    t.close()
end = time.time()

print("*******************************************************************Total time Taken=*************************************************************************************",(end - begin))
print()
print()

