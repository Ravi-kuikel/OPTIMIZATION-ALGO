BLACKHOLE OPTIMIZATION ALGORITHM

FITNESS FUNCTION:
1.SCHEDULE LENGTH
2.PRICE
3.VM UTILIZATION

DAG CONSTANTS
self.sigma = 2
self.tau = 3
w1=0.4#####Schedule Length**************************************************
w2=0.3#####Price****************************************************************
w3=0.3#####vmutilization*********************************************************************************************
vcbase = 2
cpucycle=[2,3.5,4.5,5.5,6.5]

