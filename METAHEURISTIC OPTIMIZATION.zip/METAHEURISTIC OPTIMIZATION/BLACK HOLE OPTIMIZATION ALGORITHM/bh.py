import random
import os
import math
import Dag as yo
import seqq
import glob
import time
from math import modf
import matplotlib.pyplot as plt



class bh:
    def __init__(self, p, n, m):
        self.p=p
        self.n=n
        self.m=m
        self.position = []  # Initializing populations of stars
        for i in range(p):
            x = []
            for j in range(n):
                x.append(round(random.random(), 3))
            self.position.append(x)

        self.xbest = []  # Current best is equal to initial position intially
        for i in range(p):
            self.xbest.append(self.position[i])


    def blackholeoptimization(self):
        flag=0
        iter = 50#no of iterationssssssssssssssssssssssssssssssssssss
        self.Imax = iter
        prev = 100000
        count = 0
        a=os.getcwd()
        a=a[:len(a)-6]
        a=a+"/RESULTS/"+str(self.p)+'X'+str(iter)
        try:
            os.mkdir(a)
        except OSError as error:
            pass

        a=a+'/'+name
        f=open(a,'a+')
        x=" "
        f.write(x.join(map(str,obj.seq)))
        f.write('\n')
        ft=self.fitness()
        ftb=self.fitness()
        i=ftb.index(min(ftb))
        blackhole=self.xbest[i]
        value=ftb[i]
        x=[]
        y=[]

        while count<iter:
            x.append(count+1)
            y.append(value)
            if value<prev:
                self.write(blackhole, f, value)
                prev = value
            self.updateposition(blackhole)
            eh=self.eventhorizon(value,ft)
            self.iscrossingeventhorizon(eh,blackhole)
            ft=self.fitness()
            self.updateglobalbest(ftb,ft)
            i = ftb.index(min(ftb))
            blackhole = self.xbest[i]
            value = ftb[i]
            count=count+1
        if flag==1:
            plt.plot(x, y)
            plt.xlabel("ITERATIONS")
            plt.ylabel("FITNESS")
            plt.title(name)
            plt.show()
        f.close()


    def eventhorizon(self,value,ft):
        s=0
        for i in ft:
            s=s+i
        s=value/s
        return s

    def iscrossingeventhorizon(self,eh,blackhole):
        for i in range(self.p):
            s=0
            for j in range(self.n):
                s=s+math.pow(self.position[i][j]-blackhole[j],2)
            if math.sqrt(s)<=eh:
                for k in range(self.n):
                    self.position[i][k]=round(random.random(),3)


    def updateposition(self,blackhole):
        for i in range(self.p):
            for j in range(self.n):
                self.position[i][j]=self.position[i][j]+(blackhole[j]-self.position[i][j])*random.random()


    def fitness(self):
        ft = []
        sln = []
        sun = []
        pun = []
        en = []
        ld=[]
        vu=[]
        for i in range(self.p):
            ar = []
            for j in range(self.n):
                a, b = modf(self.position[i][j])
                if a < 0:
                    a = a * -1
                a = round(a, 3)
                a = a * 1000
                s = 0
                while a > 0:
                    r = a % 10
                    s = s + r
                    a = a // 10
                ar.append(int(s % m + 1))
            sl = obj.makespan(ar)
            #su = obj.speedup(sl)
            price = obj.cost(ar)
            ##tenergy = obj.energy(ar, sl)
            ##load=obj.loadbalancing(ar)
            vmu=obj.vmutilization(ar,sl)
            sln.append(sl)
            #sun.append(su)
            pun.append(price)
            #en.append(tenergy)
            #ld.append(load)
            vu.append(vmu)
        self.slmax = max(sln)
        self.pumax = max(pun)
        #self.enmax = max(en)
        #self.sumax=max(sun)
        #self.ldmax=max(ld)
        self.vmmax=max(vu)

        for i in range(self.p):
            ft.append(obj.w1 * (sln[i] / self.slmax) + obj.w2 * (pun[i] / self.pumax) + obj.w3 *(1-(vu[i]/self.vmmax)))
        return ft

    def updateglobalbest(self, FTb, FTc):# O(p)
        for i in range(self.p):  # Updating Global best and xbest
            if FTb[i] > FTc[i]:
                self.xbest[i] =[]
                for j in self.position[i]:
                    self.xbest[i].append(j)
                # Update xbest
                FTb[i] = FTc[i]  # Update Best Fitness


    def write(self, gbest, f,value):
        ba = self.vmforparticle(gbest)
        sl = obj.makespan(ba)
        price = obj.cost(ba)
        su = obj.speedup(sl)
        tenergy = obj.energy(ba, sl)
        vutil = obj.vmutilization(ba, sl)
        load = obj.loadbalancing(ba)
        '''print("Values Corresponding to alpha\n")
        print(tabulate([[sl, price, su, tenergy, value]],
                       headers=['Schedule Length', 'Cost', 'Speedup', 'Energy', 'Fitness']), "\n")
        print("Iteration ", count + 1, "\n")'''

        if 2 > 1:
            s = "Fitness=" + str(value)
            f.write(s)
            f.write("\n")
            a = " "
            s = "Schedulelength= " + str(sl)
            f.write(s)
            f.write("\n")
            s = "Cost=" + str(price)
            f.write(s)
            f.write("\n")
            s = "Speedup=" + str(su)
            f.write(s)
            f.write("\n")
            s = "EnergyConsumption=" + str(tenergy)
            f.write(s)
            f.write("\n")
            s = "Vmutilization=" + str(vutil)
            f.write(s)
            f.write("\n")
            s = "LoadBalancing=" + str(load)
            f.write(s)
            f.write("\n")
            a = ""
            f.write("Vm Allocation \n")
            f.write(a.join(map(str, ba)))
            f.write("\n")
            f.write("\n")

    def vmforparticle(self, arr):
        x = []
        for j in range(len(arr)):
            a, b = modf(arr[j])
            if a < 0:
                a = a * -1
            a = round(a, 3)
            a = a * 1000
            s = 0
            while a > 0:
                r = a % 10
                s = s + r
                a = a // 10
            ##print(int(s % m + 1), end=" ")
            x.append(int(s % m + 1))
        return x





os.chdir(r"input")
myFiles = glob.glob('*.txt')
obj = None
pop = int(input("Enter population Size\n"))
begin = time.time()
for z in myFiles:

    name = z
    t = open(name, 'r')  # Opening Files
    t1 = t.readlines()
    n, m = t1[0].split()
    n = int(n)  # no of task
    m = int(m)  # no of vm
    arr = []

    for i in range(1, n + 1):
        arr.append(t1[i].strip().split())
    eTime = []  # Execution matrix
    for i in range(n):
        x = []
        for j in range(m):
            x.append(float(arr[i][j]))
        eTime.append(x)
    arr = []
    for i in range(n + m + 1, 2 * n + m + 1):
        arr.append(t1[i].strip().split())
    dag = []  # DAG in adjacency matrix format
    for i in range(n):
        x = []
        for j in range(n):
            x.append(float(arr[i][j]))
        dag.append(x)

    obj = yo.DAG(dag, n, m, eTime, 0.7, 0.2)
    bj = seqq.bfs()
    obj.seq = bj.seq(name)
    sum = 0
    for i in obj.seq:
        mx = 0
        for j in range(len(eTime[0])):
            if mx < obj.eTime[i - 1][j]:
                mx = obj.eTime[i - 1][j]
        sum = sum + mx

    obj.smake = sum

    obj2 = bh(pop, n, m)
    obj2.blackholeoptimization()
    
    t.close()
end = time.time()

print("*******************************************************************Total time Taken=*************************************************************************************",(end - begin))
print()
print()

