def readfile(currentfile):

    temp = []
    li = [i.strip().split() for i in open(currentfile).readlines()]

    for i in li:

        temp.append(list(map(float, i)))

    ETmat = []

    j = 0
    for i in range(1, int(temp[0][0])+1):

        ETmat.append(temp[i])
        j = i

    j = int(j+temp[0][1]+1)

    rel1, rel2, C2Prel, P2Crel = [], [], [], []
    z1, z2, count1, count2 = 0, 0, 0, 0
    for i in range(j, len(temp)):

        rel1.append(z1+1)
        rel1.append(count1)
        rel2.append(z2+1)
        rel2.append(count2)

        for k in range(int(temp[0][0])):

            if temp[j+k][z1] == 0 or temp[j+k][z1] == -1:
                pass
            else:
                count1 += 1
                rel1.append(k+1)
                rel1.append(temp[j+k][z1])
            if temp[i][k] == 0 or temp[i][k] == -1:
                pass
            else:
                count2 += 1
                rel2.append(k+1)
                rel2.append(temp[i][k])

        z1 += 1
        z2 += 1
        rel1[1] = count1
        rel2[1] = count2
        count1, count2 = 0, 0

        P2Crel.append(rel2)
        C2Prel.append(rel1)
        rel1, rel2 = [], []

    if P2Crel[0][1] != 0:
        temp = []
        x = len(P2Crel)-1
        for i in range(len(P2Crel)):

            temp.append(P2Crel[x])
            x -= 1
        P2Crel = temp
    else:
        pass

    return ETmat, C2Prel, P2Crel
