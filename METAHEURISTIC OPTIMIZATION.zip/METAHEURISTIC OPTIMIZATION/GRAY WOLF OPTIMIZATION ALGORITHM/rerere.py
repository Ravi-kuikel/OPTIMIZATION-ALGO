freq=[1]*0
print(freq)