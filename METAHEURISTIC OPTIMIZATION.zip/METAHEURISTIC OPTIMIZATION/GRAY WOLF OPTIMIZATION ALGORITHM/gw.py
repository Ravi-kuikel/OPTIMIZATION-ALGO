from math import modf
import random  as rd
import Dag as yo
import os
import glob
import pathlib
import heft_Rank as heft
import time
import math
from tabulate import tabulate
from progress.bar import IncrementalBar
import matplotlib.pyplot as plt


class greywolf:
    def __init__(self, p, n , m):  # Step 1
        self.position=[]
        self.p=p
        self.n=n
        self.m=m
        for i in range(self.p): #Randomly Initialiazing population
            ar = []
            for j in range(self.n):
                ar.append(round(rd.random(), 3))
            self.position.append(ar)
        self.a=2
        self.A=2*self.a*rd.random()-self.a
        self.C=2*rd.random()
        self.xbest = []
        for i in range(self.p):
            arr = []
            for j in range(self.n):
                arr.append(self.position[i][j])
            self.xbest.append(arr)



    def algo(self):
        flag=0####for graph plotting
        FTb= self.fitness()

        av,bv,dv=self.find(FTb)
        i, j, k = FTb.index(av), FTb.index(bv), FTb.index(dv)
        self.alpha,self.beta,self.delta=self.xbest[i],self.xbest[j],self.xbest[k]
        self.x =[]
        for i in self.alpha:
            self.x.append(i)
        iter=50#No of Iterations****************************************************************No of Iterations*********************************************************************************************************
        count=0
        bar=IncrementalBar("Progressing",max=iter)
        a = os.getcwd()
        a = a[:len(a) - 6]
        a = a + "/RESULTS/" + str(self.p) + 'X' + str(iter)
        try:
            os.mkdir(a)
        except OSError as error:
            pass

        a = a + '/' + name
        f = open(a, 'a+')
        x = " "
        f.write(x.join(map(str, obj.seq)))
        f.write("\n")
        f.write("\n")
        counter=0
        '''print("Initial Position\n")
        for i in range(self.p):
            for j in range(self.n):
                print(self.position[i][j],end=" ")
            print()
        print()
        print("Vm Corresponding To it is\n")
        self.vmcorresponding(self.position)
        print()

        print("Fitness Associated With it\n")
        for i in range(self.p):
            print(FTb[i])

        nm=self.prr()
        print(tabulate(nm, ['Scheule Length', 'Cost', 'Speed Up', ' Energy']))
        print()
        for i in nm:
            i[0]=i[0]/self.slmax
            i[1] = i[1] / self.pumax
            i[2] = i[2] / self.sumax
            i[3] = i[3] / self.enmax

        print(tabulate(nm,['Scheule Length','Cost','Speed Up',' Energy']))
        print()
        print("Alpha=",self.alpha)
        print("Beta=",self.beta)
        print("Delta=",self.delta,"\n")'''

        prev=-1
        value=av
        x=[]
        y=[]
        while count<iter: # O( No of Iterations X (O(P X N X N)+ O(PXN)))=O(No of Iterations X P X N^2)
            x.append(count+1)
            y.append(value)

            ba=self.vmforparticle(self.alpha)
            sl = obj.makespan(ba)
            price = obj.cost(ba)
            su=obj.speedup(sl)
            tenergy=obj.energy(ba,sl)
            vutil=obj.vmutilization(ba,sl)
            load=obj.loadbalancing(ba)
            ''' print("Values Corresponding to alpha\n")
            print(tabulate([[sl,price,su,tenergy,value]],headers=['Schedule Length','Cost','Speedup','Energy','Fitness']),"\n")
            print("Iteration ", count + 1,"\n")'''


            if value!= prev:
                counter = counter + 1
                s = "Fitness=" + str(value)
                f.write(s)
                f.write("\n")
                a = " "
                s = "Schedulelength= " + str(sl)
                f.write(s)
                f.write("\n")
                s = "Cost=" + str(price)
                f.write(s)
                f.write("\n")
                s="Speedup="+str(su)
                f.write(s)
                f.write("\n")
                s="EnergyConsumption="+str(tenergy)
                f.write(s)
                f.write("\n")
                s="Vmutilization="+str(vutil)
                f.write(s)
                f.write("\n")
                s="LoadBalancing="+str(load)
                f.write(s)
                f.write("\n")
                a=""
                f.write("Vm Allocation \n")
                f.write(a.join(map(str, ba)))
                f.write("\n")
                f.write("\n")
                prev=value

            self.updateposition()
            self.updateconstants(count+1,iter)
            '''print("New Position\n")
            for i in range(self.p):
                for j in range(self.n):
                    print(self.position[i][j], end=" ")
                print()
            print()
            print("Vm Corresponding to it=")
            self.vmcorresponding(self.position)
            print()
            print("Fitness Corresponding to it\n")'''
            FTc=self.fitness()
            '''for i in range(self.p):
                print(FTc[i])
            print()
            nm = self.prr()
            print(tabulate(nm, ['Scheule Length', 'Cost', 'Speed Up', ' Energy']))
            print()
            for i in nm:
                i[0] = i[0] / self.slmax
                i[1] = i[1] / self.pumax
                i[2] = i[2] / self.sumax
                i[3] = i[3] / self.enmax

            print(tabulate(nm, ['Scheule Length', 'Cost', 'Speed Up', ' Energy']))'''
            self.updateglobalbest(FTb,FTc)
            av, bv, dv = self.find(FTb)
            value=av
            i, j, k = FTb.index(av), FTb.index(bv), FTb.index(dv)
            self.alpha, self.beta, self.delta = self.xbest[i], self.xbest[j], self.xbest[k]
            for i in range(self.n):
                self.x[i]=(self.alpha[i]+self.beta[i]+self.delta[i])/3
            count=count+1
            bar.next()
            '''print()
            print("Alpha=", self.alpha)
            print("Beta=", self.beta)
            print("Delta=", self.delta, "\n")'''
        if flag==1:
            plt.plot(x, y)
            plt.xlabel("ITERATIONS")
            plt.ylabel("FITNESS")
            plt.title(name)
            plt.show()
        f.close()
        bar.finish()




    def fitness(self):
        ft = []
        sln=[]
        sun=[]
        pun=[]
        en=[]
        for i in range(self.p):# O( P x n x n)= O(P X N X N)
            ar = []
            for j in range(self.n):
                a, b = modf(self.position[i][j])
                if a < 0:
                    a = a * -1
                a = round(a, 3)
                a = a * 1000
                s = 0
                while a > 0:
                    r = a % 10
                    s = s + r
                    a = a // 10
                ar.append(int(s % m + 1))
            sl=obj.makespan(ar)
            su=obj.speedup(sl)
            price=obj.cost(ar)
            tenergy=obj.energy(ar,sl)
            sln.append(sl)
            sun.append(su)
            pun.append(price)
            en.append(tenergy)

        self.slmax=max(sln)
        self.sumax=max(sun)
        self.pumax=max(pun)
        self.enmax=max(en)

        for i in range(self.p):
            ft.append(obj.w1*(sln[i]/self.slmax)+obj.w2*(pun[i]/self.pumax)+obj.w3*(1-(sun[i]/self.sumax))+obj.w4*(en[i]/self.enmax))
        '''for i in range(self.p):
            ft.append(obj.w1*(sln[i])+obj.w2*(pun[i])+obj.w3*(1-(sun[i]))+obj.w4*(en[i]))'''




        return ft

    def find(self,FTb):#O(P)
        alpha = math.inf
        beta = math.inf
        delta = math.inf
        for i in range(self.p):  # Finding Alpha Beta Delta
            if (FTb[i] < alpha):
                delta = beta
                beta = alpha
                alpha = (FTb[i])

            elif (FTb[i] < beta):
                delta = beta
                beta = (FTb[i])
            elif (FTb[i] < delta):
                delta = (FTb[i])
            else:
                pass
        return alpha,beta,delta

    def updateposition(self): # O(P X N)
        for i in range(self.p):
            for j in range(self.n):
                d=abs(self.C*self.position[i][j]-self.x[j])
                self.position[i][j] = abs(self.position[i][j] - self.A*d)

    def updateconstants(self,t,iter): # O(1)
        self.a=2-((t+1)/iter)
        self.A=2*self.a*rd.random()-self.a
        self.C=2*rd.random()

    def updateglobalbest(self, FTb, FTc): #O(P)
        for i in range(self.p):  # Updating Global best and xbest
            if FTb[i] > FTc[i]:
                self.xbest[i] = []
                for j in self.position[i]:
                    self.xbest[i].append(j)
                # Update xbest
                FTb[i] = FTc[i]  # Update Best Fitness


    def vmforparticle(self, arr):
        x = []
        for j in range(len(arr)):
            a, b = modf(arr[j])
            if a < 0:
                a = a * -1
            a = round(a, 3)
            a = a * 1000
            s = 0
            while a > 0:
                r = a % 10
                s = s + r
                a = a // 10
            ##print(int(s % m + 1), end=" ")
            x.append(int(s % m + 1))
        return x

    def vmcorresponding(self, arr):
        for i in range(len(arr)):
            for j in range(len(arr[0])):
                a, b = modf(arr[i][j])
                if a < 0:
                    a = a * -1
                a = round(a, 3)
                a = a * 1000
                s = 0
                while a > 0:
                    r = a % 10
                    s = s + r
                    a = a // 10
                print(int(s % m + 1), end=" ")
            print()


    def prr(self):
        xrr=[]
        for i in self.position:
            a=self.vmforparticle(i)
            sl=obj.makespan(a)
            price=obj.cost(a)
            su=obj.speedup(sl)
            en=obj.energy(a,sl)
            xrr.append([sl,price,su,en])
        return xrr


begin = time.time()
os.chdir(r"input")
myFiles = glob.glob('*.txt')
obj = None
pop = int(input("Enter population Size\n"))
for z in myFiles:
    name = z
    t = open(name, 'r')  # Opening Files
    t1 = t.readlines()
    n, m = t1[0].split()
    n = int(n)  # no of task
    m = int(m)  # no of vm
    arr = []

    for i in range(1, n + 1):
        arr.append(t1[i].strip().split())
    eTime = []  # Execution matrix
    for i in range(n):
        x = []
        for j in range(m):
            x.append(float(arr[i][j]))
        eTime.append(x)
    arr = []
    for i in range(n + m + 1, 2 * n + m + 1):
        arr.append(t1[i].strip().split())
    dag = []  # DAG in adjacency matrix format
    for i in range(n):
        x = []
        for j in range(n):
            x.append(float(arr[i][j]))
        dag.append(x)

    obj = yo.DAG(dag, n, m, eTime,0.7,0.2)
    obj.seq = (heft.HEFT(name))
    sum=0
    for i in obj.seq:
        mx=0
        for j in range(len(eTime[0])):
            if mx<obj.eTime[i-1][j]:
                mx=obj.eTime[i-1][j]
        sum=sum+mx

    obj.smake=sum

    obj2 = greywolf(pop, n,m)
    obj2.algo()
    t.close()
    
end = time.time()
print("Total Time taken=",end-begin)
