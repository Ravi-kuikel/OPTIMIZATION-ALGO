Gray Wolf Optimizations
Fitness parameter(
1.Schedule Length
2.Cost
3.Energy
4.SpeedUp)

Cost Function:
Sigma=2
Tau=3
vcbase = 2        
cpucycle=[2,3.5,4.5,5.5,6.5]
mincpucycle=2

w1=0.4#####Schedule Length
w2=0.1#####Price
w3=0.2#####SpeedUp
w4=0.3######Energy
Ebusy=0.7####Energy Consumption When Busy
Eidle=0.2

Total Time Complexity=O(No of Iterations X P X N^2)
and P=No of Populations, N= No of tasks in a Dag
