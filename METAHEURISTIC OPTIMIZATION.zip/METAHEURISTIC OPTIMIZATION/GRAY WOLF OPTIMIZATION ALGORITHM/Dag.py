import random as rd
from itertools import permutations
import math
class DAG:
    def __init__(self, dag, n, m, eTime,ebusy,eidle):
        arr = []  # This matrixtttttttttttttttttttttttttttt represents parent child relationship and communication time
        self.sigma = 2
        self.tau = 3
        self.w = 0.7
        self.w1=0.4#####Schedule Length**************************************************
        self.w2=0.1#####Price****************************************************************
        self.w3=0.2#####SpeedUp*********************************************************************************************
        self.w4=0.3######Energy*********************************************************************************************************
        self.vcbase = 2
        self.cpucycle=[2,3.5,4.5,5.5,6.5,7.5]
        self.mincpucycle=min(self.cpucycle[:m])
        self.Ebusy=ebusy
        self.Eidle=eidle
        self.n=n
        self.m=m
        self.cloud = {}
        x = 1
        for i in range(1, self.m + 1, 2):
            self.cloud[x] = [i]
            if i + 1 != self.m + 1:
                self.cloud[x].append(i + 1)
            x = x + 1

        for i in range(n):
            arr.append([])
        for i in range(n):
            for j in range(n):
                if i != j:
                    if dag[j][i]!=0 and dag[j][i]!=-1:
                        arr[i].append((j + 1, dag[j][i]))

        self.dag = arr
        '''for i in self.dag:
            print(i)'''
        #Printing Dag##for i in range(n):
        #Printing Dag   #print(i + 1, " ", self.dag[i])
        self.eTime = eTime
        ## 83t self.seq = [1,5,4,2,3,6,7,8]# Order in which task is to be executed
        ##epigenomic 100 self.seq=[100, 99, 98, 85, 97, 76, 82, 84, 86, 83, 74, 78, 89, 87, 90, 75, 91, 77, 80, 92, 93, 61, 94, 88, 62, 96, 95, 73, 60, 79, 52, 81, 58, 56, 51, 50, 59, 54, 63, 65, 53, 68, 67, 72, 66, 71, 64, 55, 69, 70, 35, 57, 38, 37, 44, 36, 43, 30, 42, 34, 45, 26, 39, 41, 28, 40, 49, 31, 48, 27, 32, 29, 33, 46, 47, 11, 14, 12, 18, 17, 7, 10, 21, 15, 2, 20, 13, 6, 24, 16, 5, 19, 25, 22, 9, 23, 4, 3, 8, 1]
        self.seq = []

        ##for i in range(n):

    ##self.seq.append(i+1)

    def makespan(self, vmassign): # O(height of Dag) therefore max height can be n so lets say O(n)
        vms = []  # This list contains starttime and finishtime for each vm
        for i in range(len(self.eTime[0])):
            vms.append([-1, -1])
        tst = []  # This list contains starttime,finishtime,vmassigned for each task
        for i in range(len(vmassign)):
            tst.append([-1, -1, vmassign[i]])

        count = 0

        while count < len(self.seq):
            task = self.seq[count]
            parents = self.dag[task - 1]
            vm = vmassign[task - 1]
            if parents == None:
                if vms[vm - 1] [0]!= -1:
                    start = vms[vm - 1][1]
                    finish = start + self.eTime[task - 1][vm - 1]
                else:
                    start = 0
                    finish = finish = start + self.eTime[task - 1][vm - 1]
            else:

                mx = 0
                for i in parents:###version 2  1 cloud with 2 vms
                    node, ct = i
                    pvm=tst[node-1][2]
                    z=0
                    if pvm==vm:
                    	z=1
                    if mx < tst[node - 1][1] + ct and z==0:
                        mx = tst[node - 1][1] + ct
                    elif mx < tst[node - 1][1]:
                        mx = tst[node - 1][1]
                    else:
                        pass
                if mx > vms[vm - 1][1]:
                    start = mx
                else:
                    start = vms[vm - 1][1]
                finish = start + self.eTime[task - 1][vm - 1]

            vms[vm - 1][0] = start
            vms[vm - 1][1] = finish
            tst[task - 1][0], tst[task - 1][1] = start, finish
            count += 1
            #print(round(start,2),"   ",round(finish,2),"  ",vm)
        mx = 0
        for i in tst:
            x, y, z = i
            if y > mx:
                mx = y
        return mx
    def cost(self, vmassign): # O(n)
        cost = 0
        costmat=[]
        for i in self.seq:
            vm = vmassign[i - 1]
            et = self.eTime[i - 1][vm - 1]
            unit = math.ceil(et / self.tau)
            rate = self.sigma * self.vcbase*math.pow(math.e,(self.cpucycle[vm-1]/self.mincpucycle))
            cost = cost+unit * rate


        return cost

    def speedup(self,sl):#O(1)
        return (self.smake/sl)

    def energy(self,vmassign,sl): # O(n)
        dix={}
        for i in range(self.n):
            if vmassign[i] in dix:
                dix[vmassign[i]].append(i+1)
            else:
                dix[vmassign[i]]=[i+1]
        E=0
        for i in range(self.m):
            if i+1 not in dix:
                dix[i+1]=[0]
        for i in dix:
            arr=dix[i]
            busy=0
            for j in arr:
                busy=busy+self.eTime[j-1][i-1]
            E=E+busy*self.Ebusy+(sl-busy)*self.Eidle

        return E

    def vmutilization(self,vmassign,sl):# O(n)
        dix = {}
        for i in range(self.n):
            if vmassign[i] in dix:
                dix[vmassign[i]].append(i + 1)
            else:
                dix[vmassign[i]] = [i + 1]
        for i in range(self.m):
            if i + 1 not in dix:
                dix[i + 1] = [0]
        busy=0
        for i in dix:
            arr=dix[i]
            for j in arr:
                busy=busy+self.eTime[j-1][i-1]
        at=((busy)/(self.m*sl))

        return at
    def loadbalancing(self,vmassign):#O(n)+O(m)+O(m)+O(n)=2(O(n)+O(m))=O(n)
        dix = {}
        for i in range(self.n):    # O(n)
            if vmassign[i] in dix:
                dix[vmassign[i]].append(i + 1)
            else:
                dix[vmassign[i]] = [i + 1]
        for i in range(self.m):   #  O(m)
            if i + 1 not in dix:
                dix[i + 1] = [0]
        busy = 0
        for i in dix:            # O(m)
            arr = dix[i]
            for j in arr:
                busy = busy + self.eTime[j - 1][i - 1]
        avg=(busy/self.m)
        busy=0
        sum=0
        for i in dix:           #O(m x (n/m)) ~= O(n)
            arr = dix[i]
            busy=0
            for j in arr:
                busy = busy + self.eTime[j - 1][i - 1]
            sum=sum+math.pow((busy-avg),2)

        sum=sum/(self.m)
        sum=math.sqrt(sum)
        return sum





















   










