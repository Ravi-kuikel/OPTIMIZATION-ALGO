
import txtreader as reader


def HEFT(currentfile):
    ETmat, l2, taskinfo = reader.readfile(currentfile)

    def childRelation(t_no):
        list = []
        list.clear()
        currenttask = taskinfo[t_no]

        if currenttask[1] == 0:
            return [0, 0]
        else:
            k = 1

            while k < len(currenttask)-1:

                list.append(currenttask[k+2]+float(rank[currenttask[k+1]]))

                k += 2

            return list

    rank = ['0']*(len(taskinfo)+1)
    cnt = len(ETmat)-1
    t_no = 0
    for rk in taskinfo:

        l = childRelation(t_no)

        rank[rk[0]] = "{:.3f}".format(
            sum(ETmat[cnt])/len(ETmat[cnt]) + max(l))

        t_no += 1
        cnt -= 1

    temp = list(map(float, rank))

    urank = []
    for i in range(1, len(temp)):
        urank.append([i, temp[i]])

    indx = sorted(range(len(temp)), key=temp.__getitem__)
    indx.reverse()

    priOrder = []
    for i in range(len(temp)):
        priOrder.append([indx[i], temp[indx[i]]])

    priOrder.pop(len(priOrder)-1)

    Seq = []
 
    
    for i in priOrder:
        #print(i[0], "-->", end="")
        Seq.append(i[0])

    return Seq

